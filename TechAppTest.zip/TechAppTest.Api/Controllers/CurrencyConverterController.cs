﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using TechAppTest.Business;

namespace TechAppTest.Api.Controllers
{
    [Route("api/[controller]")]
    [EnableCors("TechAppTestApiAllowPolicy")]
    [ApiController]
    public class CurrencyConverterController : ControllerBase
    {
        public INumberToCurrency _numberToWordsConversion { get; set; }

        public CurrencyConverterController(INumberToCurrency numberToWordsConversion)
        {
            _numberToWordsConversion = numberToWordsConversion;
        }
        // GET api/CurrencyConverter/10
        [HttpGet("{inputnumber}")]
        public ActionResult<string> Get(string inputnumber)
        {
            return _numberToWordsConversion.BuildCurrencyConvertion(inputnumber);
        }
    }
}
