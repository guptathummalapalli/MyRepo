﻿namespace TechAppTest.Models
{
    public class FormModel
    {
        public string InputName { get; set; }
        public string InputNumber { get; set; }
    }
}