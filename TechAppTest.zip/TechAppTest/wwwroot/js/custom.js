﻿$(".btn-submit").click(function (evt) {
    var name = $(".inputName").val();
    var number = $(".inputNumber").val();
    var apiUrl = "http://localhost:49646/api/CurrencyConverter/" + number
    if (isNaN(number)) {
        evt.preventDefault();
        $(".displayName, .displayFormattedNumber").empty();
        $(".display-error").html("Enter a valid number");
    }
    else {
        $(".display-error").empty();
        $.ajax({
            cache: false,
            url: apiUrl,
            success: function (result) {
                $(".displayName").html(name);
                $(".displayFormattedNumber").html(result);
            }
        });
    }
});