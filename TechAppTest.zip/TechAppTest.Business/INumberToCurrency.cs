﻿namespace TechAppTest.Business
{
    public interface INumberToCurrency
    {
        string BuildCurrencyConvertion(string number);
    }
}
